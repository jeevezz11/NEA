import tkinter as tk
import main as tm

class Menu:
    def __init__(self, root):
        self.root = root
        self.root.title("Menu GUI")

        tm.newOrder()

        self.confirmation_status = False

        self.button_frame = tk.Frame(self.root, padx=10, pady=10)
        self.button_frame.grid(row=0, column=0, rowspan=6)

        self.reorder_button = tk.Button(root, text="Reorder", command=self.reorder, state=tk.DISABLED)
        self.reorder_button.grid(row=6, column=0, padx=10, pady=10, sticky="ew")

        button_info = [
            ("Small Fish", self.button_one_clicked),
            ("Regular Fish", self.button_two_clicked),
            ("Large Fish", self.button_three_clicked),
            ("Regular Chips", self.button_four_clicked),
            ("Large Chips", self.button_five_clicked),
            ("7\" Pizza", self.button_six_clicked),
            ("10\" Pizza", self.button_seven_clicked),
            ("12\" Pizza", self.button_eight_clicked),
            ("Kebab Wrap", self.button_nine_clicked),
            ("Mega Kebab Wrap", self.button_ten_clicked),
            ("Vegan Kebab Wrap", self.button_eleven_clicked),
            ("Chicken Tikka Wrap", self.button_twelve_clicked),
            ("Small Sauce", self.button_thirteen_clicked),
            ("Large Sauce", self.button_fourteen_clicked),
            ("Can Of Pop", self.button_fifteen_clicked),
            ("Bottle Of Pop", self.button_sixteen_clicked),
            ("Total", self.button_total_clicked)
        ]

        self.buttons = []

        for text, command_func in button_info:
            button = tk.Button(self.button_frame, text=text, width=10, height=3, command=command_func, wraplength= 80)
            self.buttons.append(button)

        row_count = 0
        column_count = 0

        loop = 0

        for button in self.buttons:
            if loop == 16:
                button.grid(rowspan=4, columnspan=4, padx=5, pady=(15,0), sticky="ew")
            else:
                button.grid(row=row_count, column=column_count, padx=5, pady=5)
                column_count += 1
                if column_count == 4:
                    column_count = 0
                    row_count += 1
                loop += 1

        self.output_text = tk.Text(root, width=40, height=10)
        self.output_text.grid(row=0, column=1, rowspan=6, padx=10, pady=(10, 0), sticky="nsew")

        scrollbar = tk.Scrollbar(root, command=self.output_text.yview)
        scrollbar.grid(row=0, column=2, rowspan=6, sticky="ns")

        self.output_text.config(yscrollcommand=scrollbar.set)

        self.remove_button = tk.Button(root, text="Remove Last Item", command=self.remove_selected_line)
        self.remove_button.grid(row=6, column=1, padx=10, sticky="ew")

    def button_one_clicked(self):
        self.output_text.insert(tk.END, "Small Fish - £4.40\n")
        tm.addFood("sml fish")

    def button_two_clicked(self):
        self.output_text.insert(tk.END, "Regular Fish - £6.90\n")
        tm.addFood("reg fish")

    def button_three_clicked(self):
        self.output_text.insert(tk.END, "Large Fish - £8.50\n")
        tm.addFood("lrg fish")

    def button_four_clicked(self):
        self.output_text.insert(tk.END, "Regular Chips - £2.40\n")
        tm.addFood("reg chips")

    def button_five_clicked(self):
        self.output_text.insert(tk.END, "Large Chips - £2.90\n")
        tm.addFood("lrg chips")

    def button_six_clicked(self):
        self.customisation_menu("7\" Pizza")

    def button_seven_clicked(self):
        self.customisation_menu("10\" Pizza")

    def button_eight_clicked(self):
        self.customisation_menu("12\" Pizza")

    def button_nine_clicked(self):
        self.output_text.insert(tk.END, "Kebab Wrap - £5.50\n")
        tm.addFood("kebab wrap")

    def button_ten_clicked(self):
        self.output_text.insert(tk.END, "Mega Kebab Wrap - £9.99\n")
        tm.addFood("mega kebab wrap")

    def button_eleven_clicked(self):
        self.output_text.insert(tk.END, "Vegan Kebab Wrap - £6.90\n")
        tm.addFood("vegan kebab wrap")

    def button_twelve_clicked(self):
        self.output_text.insert(tk.END, "Chicken Tikka Wrap - £6.50\n")
        tm.addFood("chicken wrap")

    def button_thirteen_clicked(self):
        self.output_text.insert(tk.END, "Small Sauce - £1.10\n")
        tm.addFood("sml sauce")

    def button_fourteen_clicked(self):
        self.output_text.insert(tk.END, "Large Sauce - £1.40\n")
        tm.addFood("lrg sauce")

    def button_fifteen_clicked(self):
        self.output_text.insert(tk.END, "Can Of Pop - £1.00\n")
        tm.addFood("can of pop")

    def button_sixteen_clicked(self):
        self.output_text.insert(tk.END, "Bottle Of Pop - £1.50\n")
        tm.addFood("bottle of pop")

    def button_total_clicked(self):
        if not self.confirmation_status:
            receipt = tm.doReceipt()
            self.output_text.insert(tk.END, receipt)

            self.output_text.see(tk.END)

            self.confirmation_status = True

            for button in self.buttons:
                button.config(state=tk.DISABLED)

            self.remove_button.config(state=tk.DISABLED)
            self.reorder_button.config(state=tk.NORMAL)

    def remove_selected_line(self):
        tm.removeLastItem()
        if not self.confirmation_status:
            current_line = self.output_text.index(tk.INSERT)
            current_line_number = int(current_line.split('.')[0])

            previous_line_index = f"{current_line_number - 1}.0"

            self.output_text.delete(previous_line_index, current_line)

    def reorder(self):
        tm.newOrder()

        self.output_text.delete("1.0", tk.END)
        self.confirmation_status = False

        for button in self.buttons:
            button.config(state=tk.NORMAL)

        self.remove_button.config(state=tk.NORMAL)
        self.reorder_button.config(state=tk.DISABLED)

    def customisation_menu(self, pizza_size):
        customization_window = tk.Toplevel(self.root)
        customization_window.title(f"{pizza_size} Customisation")
        pizza_size = pizza_size[:3]
        pizza_size = pizza_size.strip()

        def custom_option_clicked(option_text):

            text = tm.getPizzaPrice(pizza_size, option_text)

            self.output_text.insert(tk.END, text)
            customization_window.destroy() 

        custom_options = [
            "Margerita", "Bolognese", "Hawaiian", "Vegetarian",
            "Chicken Kiev", "Hot Shot", "Chicken Tikka", "Tuna",
            "Pepperoni", "Smokey Special", "Chicken", "Chicken And Mushroom",
            "Geordie Kebab Delight", "Plain Kebab", "BBQ Chicken", "Meat Feast",
        ]

        row_count = 0
        column_count = 0

        for option_text in custom_options:
            custom_button = tk.Button(customization_window, text=option_text, width=10, height=3,
                                      command=lambda opt=option_text: custom_option_clicked(opt), wraplength=80)
            custom_button.grid(row=row_count, column=column_count, padx=5, pady=5)
            column_count += 1
            if column_count == 4:
                column_count = 0
                row_count += 1
            
if __name__ == "__main__":
    root = tk.Tk()
    app = Menu(root)
    root.mainloop()
