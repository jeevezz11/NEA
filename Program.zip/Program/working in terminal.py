import datetime
import os

currentDate = datetime.date.today()

folderName = currentDate.strftime("%Y-%m-%d") #in this format so folders can sort by earliest created when sorted by name
folderPath = os.path.join("/home/jeevan/Desktop/NEA/Program", folderName)

if not os.path.exists(folderPath):
    os.makedirs(folderPath)
    print(f"Folder '{folderName}' created at '{folderPath}'")
else:
    print(f"Folder for receipt found")

print()

def getOrderNumber():

    if os.path.exists("orderNumber.txt"):
        with open("orderNumber.txt", "r") as oF:
            lastDateStr, orderNumberStr = oF.readline().split(',')
            lastDate = datetime.date.fromisoformat(lastDateStr)
            orderNumber = int(orderNumberStr)       

        if currentDate > lastDate:
            orderNumber = 1
    else:
        print("Order history not found")
        exit()

    with open("orderNumber.txt", "w") as oF:
        oF.write(f"{currentDate.isoformat()},{orderNumber + 1}")

    return orderNumber

orderNumber = getOrderNumber()

print(f"New order number: {orderNumber}")

fileName = "items.txt"
receipt = []

try:
    with open(fileName, "r") as itemsF:
   
        foodPrices = {}
        for line in itemsF:
            parts = line.strip().split('£')
            if len(parts) == 2:
                food, price = parts
                if food[-2] == ",":
                    food = food[:-2]
                if price[-2]== ",":
                    price = price[:-2]

                foodPrices[food.strip()] = float(price.strip())

except FileNotFoundError:
    print(f"File '{fileName}' not found.")
except Exception as e:
    print(f"An error occurred: {e}")

def doReceipt():
    
    print()
    customerName = input("Enter the customer name: ")
    print()

    totalPrice = 0.0

    for i in range (len(receipt)):
        totalPrice = float(totalPrice) + float(receipt[i][1])
        totalPrice = f"{totalPrice:.2f}"

    customDirectory = f"/home/jeevan/Desktop/NEA/Program/{folderName}"
    fileName = f"order {orderNumber}.txt"

    filePath = os.path.join(customDirectory, fileName)

    currentTime = datetime.datetime.now().time()
    formattedTime = currentTime.strftime("%H:%M:%S")

    with open(filePath, "w") as r:

        r.write(f"{currentDate} {formattedTime}\n")
        r.write(f"\nCustomer Name: {customerName}\n\n")

        for item in receipt:
            itemName = item[0]
            itemPrice = item[1]
            formattedItem = f"{itemName}: £{itemPrice}"
            r.write(formattedItem + "\n")

        r.write(f"\nTotal Price: £{totalPrice}")

    print(f"The total price of this transaction is: £{totalPrice}")

def addFood():           

    print()
    foodItem = input("Enter a food item: ").strip().lower()
    quantity = int(input("Quantity of item: "))
    print()
    if foodItem in foodPrices:
        price = foodPrices[foodItem]
        price = f"{price:.2f}"
        
        for i in range(quantity):
            receipt.append([foodItem, price])

        print(f"The price of a {foodItem} is £{price}")
    else:
        print(f"{foodItem} not found in the price list.")

    print()
    option = input("Would you like to add more food (y/n)?: ")

    if option == "y":
        addFood()
    elif option == "n":
        doReceipt()

addFood()

