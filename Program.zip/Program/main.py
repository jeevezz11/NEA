import datetime
import os

currentDate = datetime.date.today()

folderName = currentDate.strftime("%Y-%m-%d") #in this format so folders can sort by earliest created when sorted by name
folderPath = os.path.join(f"{os.curdir}/Receipts", folderName)

if not os.path.exists(folderPath):
    os.makedirs(folderPath)
    print(f"Folder '{folderName}' created at '{folderPath}'")
else:
    print(f"Folder for receipt found")

def getOrderNumber():

    if os.path.exists("orderNumber.txt"):
        with open("orderNumber.txt", "r") as oF:
            lastDateStr, orderNumberStr = oF.readline().split(',')
            lastDate = datetime.date.fromisoformat(lastDateStr)
            orderNumber = int(orderNumberStr)       

        if currentDate > lastDate:
            orderNumber = 1
    else:
        print("Order history not found")
        exit()

    with open("orderNumber.txt", "w") as oF:
        oF.write(f"{currentDate.isoformat()},{orderNumber + 1}")

    return orderNumber

def newOrder():

    global orderNumber
    orderNumber = getOrderNumber()

    print(f"New order number: {orderNumber}")

    fileName = "items.txt"

    global receipt
    receipt = []

    try:
        with open(fileName, "r") as itemsF:
            
            global foodPrices
            foodPrices = {}

            for line in itemsF:
                parts = line.strip().split('£')
                if len(parts) == 2:
                    food, price = parts
                    if food[-2] == ",":
                        food = food[:-2]
                    if price[-2]== ",":
                        price = price[:-2]

                    foodPrices[food.strip()] = float(price.strip())

    except FileNotFoundError:
        print(f"File '{fileName}' not found.")
    except Exception as e:
        print(f"An error occurred: {e}")

def doReceipt():
    
    totalPrice = 0.0

    for i in range (len(receipt)):
        totalPrice = float(totalPrice) + float(receipt[i][1])
        totalPrice = f"{totalPrice:.2f}"

    customDirectory = f"{os.curdir}/Receipts/{folderName}"
    fileName = f"order {orderNumber}.txt"

    filePath = os.path.join(customDirectory, fileName)

    currentTime = datetime.datetime.now().time()
    formattedTime = currentTime.strftime("%H:%M:%S")

    with open(filePath, "w") as r:

        r.write(f"{currentDate} {formattedTime}\n\n") 

        for item in receipt:
            itemName = item[0]
            itemPrice = item[1]
            formattedItem = f"{itemName}: £{itemPrice}"
            r.write(formattedItem + "\n")

        r.write(f"\nTotal Price: £{totalPrice}")

    return (f"\nTotal: £{totalPrice}")

def addFood(foodItem):           

    if foodItem in foodPrices:
        price = foodPrices[foodItem]
        price = f"{price:.2f}"
        receipt.append([foodItem, price])

def getPizzaPrice(size, toppings):
    
    filePath = (f"/home/jeevan/Desktop/NEA/Program/Pizza Customisation/{size} toppings.txt")

    try:
        with open(filePath, "r") as top:
            
            global toppingsList
            toppingsList = {}

            for line in top:
                parts = line.strip().split('£')
                if len(parts) == 2:
                    food, price = parts
                    if food[-2] == ",":
                        food = food[:-2]
                    if price[-2]== ",":
                        price = price[:-2]
                

                    toppingsList[food.strip()] = float(price.strip())

            if toppings in toppingsList:

                price = toppingsList[toppings]
                price = f"{price:.2f}"
                receipt.append([(f"{size} {toppings} pizza"), price])

                return (f"{size} {toppings} Pizza - £{price}\n")
    
    except FileNotFoundError:
        print(f"File '{filePath}' not found.")
    except Exception as e:
        print(f"An error occurred: {e}")

def removeLastItem():
    receipt.pop()





